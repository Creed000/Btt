# BTT v0.1

Foundation structure for the BTT platform.
