from fastapi import FastAPI

app = FastAPI(title="BTT Platform")

@app.get("/")
def root():
    return {"status": "ok", "project": "BTT"}
